CHINOTECH ONE MARKETPLACE
Upload the whole CHINOTECH-ONE folder to GitHub.
Keep index.html, manifest.webmanifest, icon.svg and the images folder together.

PAYSTACK CHECKOUT:
https://paystack.shop/pay/-lx13gxkac

IMAGE NOTE:
Every catalog product has its own fixed local image file in /images. These are product-specific marketplace illustration assets, not remote keyword-generated images. For a commercial launch, replace them with photographs you have permission to use.
