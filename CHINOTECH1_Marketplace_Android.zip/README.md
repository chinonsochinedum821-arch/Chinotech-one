# CHINOTECH1 Marketplace Android App

First working Android wrapper for the existing CHINOTECH1 Marketplace website.

Website:
https://chinonsochinedum821-arch.github.io/Chinotech-one/

## Build
Open this project in Android Studio, let Gradle sync, then choose:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The app requests INTERNET permission and loads the existing HTTPS website in a WebView.
