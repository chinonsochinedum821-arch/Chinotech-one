plugins {
    id("com.android.application")
    kotlin("android")
}
android {
    namespace = "com.chinotech1.marketplace"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.chinotech1.marketplace"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
